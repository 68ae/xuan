<?php
header("Content-type: text/html; charset=utf-8"); 
$serverName = "120.27.38.31"; //数据库服务器地址
$uid = "sa"; //数据库用户名
$pwd = "zxyl2015"; //数据库密码
$connectionInfo = array("UID"=>$uid, "PWD"=>$pwd, "Database"=>"giftbox");
$conn = sqlsrv_connect( $serverName, $connectionInfo);
if( $conn == false)
{
echo "连接失败！";
die( print_r( sqlsrv_errors(), true));
}else{
echo "连接成功！";	
}
$query = sqlsrv_query($conn, "select * from tb_product");
while($row = sqlsrv_fetch_array($query))
{
  print_r($row);
}
?>